import re
import logging
from typing import Dict, Any, List

logger = logging.getLogger("CrossDocReconciler")

class CrossDocReconciler:
    @staticmethod
    def extract_process_id(text: str) -> str:
        """Extracts 5-digit Shibumi / Process ID (e.g., 10180, 10478, 10596)."""
        match = re.search(r"\b(1\d{4})\b", text)
        return match.group(1) if match else ""

    def reconcile_project(self, classified_docs: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Executes cross-document verification across PDD, SDD, Test Cases, and User Manual.
        """
        reconciliation_issues = []
        alignment_findings = {}

        pdd = classified_docs.get("PDD", {})
        sdd = classified_docs.get("SDD", {})
        test = classified_docs.get("TEST_CASES", {})
        manual = classified_docs.get("USER_MANUAL", {})

        # -------------------------------------------------------------
        # 1. Process ID Alignment Check
        # -------------------------------------------------------------
        pdd_id = self.extract_process_id(pdd.get("full_text", "")[:500])
        sdd_id = self.extract_process_id(sdd.get("full_text", "")[:500])
        test_id = self.extract_process_id(test.get("file_name", ""))
        manual_id = self.extract_process_id(manual.get("full_text", "")[:500])

        ids = {"PDD": pdd_id, "SDD": sdd_id, "TEST_CASES": test_id, "USER_MANUAL": manual_id}
        detected_ids = [v for v in ids.values() if v]

        alignment_findings["detected_process_ids"] = ids
        if len(set(detected_ids)) > 1:
            reconciliation_issues.append({
                "severity": "CRITICAL",
                "area": "Process ID Mismatch",
                "message": f"Conflicting Shibumi Process IDs detected across artifacts: {ids}. Ensure all files belong to the same automation."
            })
        else:
            alignment_findings["unified_process_id"] = detected_ids[0] if detected_ids else "UNKNOWN"

        # -------------------------------------------------------------
        # 2. Exception Handling Alignment: PDD <-> SDD <-> Test Cases
        # -------------------------------------------------------------
        pdd_text = pdd.get("full_text", "").lower()
        sdd_text = sdd.get("full_text", "").lower()
        test_str = str(test.get("sheets", {})).lower()

        # Check for typical exception classes
        exception_keywords = ["login", "credentials", "missing file", "timeout", "sap", "excel"]
        unhandled_in_sdd = []
        untested_in_qa = []

        for kw in exception_keywords:
            if kw in pdd_text:
                if kw not in sdd_text:
                    unhandled_in_sdd.append(kw)
                if kw not in test_str:
                    untested_in_qa.append(kw)

        if unhandled_in_sdd:
            reconciliation_issues.append({
                "severity": "HIGH",
                "area": "Exception Gap (PDD -> SDD)",
                "message": f"Business exceptions regarding {unhandled_in_sdd} defined in PDD are missing technical recovery actions in SDD Section 3.4."
            })

        if untested_in_qa:
            reconciliation_issues.append({
                "severity": "HIGH",
                "area": "Testing Gap (SDD -> Test Cases)",
                "message": f"Technical exception flows regarding {untested_in_qa} lack corresponding QA test cases in the test workbook."
            })

        # -------------------------------------------------------------
        # 3. Application & Tool Parity: PDD Section 6 <-> SDD Section 6
        # -------------------------------------------------------------
        apps = ["sap", "excel", "icertis", "sharepoint", "outlook"]
        pdd_apps = [a for a in apps if a in pdd_text]
        sdd_apps = [a for a in apps if a in sdd_text]

        missing_sdd_apps = [a for a in pdd_apps if a not in sdd_apps]
        if missing_sdd_apps:
            reconciliation_issues.append({
                "severity": "HIGH",
                "area": "System Access Gap",
                "message": f"Applications {missing_sdd_apps} listed in PDD Required System Access are not documented in SDD Applications/Tools."
            })

        return {
            "reconciliation_passed": len([i for i in reconciliation_issues if i["severity"] == "CRITICAL"]) == 0,
            "issues": reconciliation_issues,
            "alignment_summary": alignment_findings
        }
