"""
Document Classifier Module.
Classifies files strictly by internal content, headings, and tables.
Reads schema taxonomy directly from config/doc_standards.json with fallback pattern matching.
Reliably detects:
- PDD (Process Definition Document)
- SDD (Solution Design Document)
- TEST_CASES (QA Test Cases & Results Workbook)
- USER_MANUAL (Bot User Manual / Operational RunBook)
- APPROVALS (Sign-off & Approvals Record / Email)
- EXTRANEOUS (Unrecognized non-target files to quarantine)
"""

import json
import logging
from typing import Dict, Any, Tuple
from .heading_extractor import HeadingExtractor

logger = logging.getLogger("Classifier")

class DocumentClassifier:
    def __init__(self, standards_path: str = "config/doc_standards.json"):
        with open(standards_path, "r", encoding="utf-8") as f:
            self.standards = json.load(f)["document_types"]
        self.extractor = HeadingExtractor()

    def classify(self, parsed_doc: Dict[str, Any]) -> Tuple[str, float, Dict[str, Any]]:
        """
        Examines internal content, headings, and tables.
        Returns: (doc_type, confidence, metadata)
        """
        if not parsed_doc:
            return "EXTRANEOUS", 0.0, {"reason": "Empty or unparsed content"}

        full_text = parsed_doc.get("full_text", "").lower()
        headings = [h.lower() for h in self.extractor.extract_normalized_headings(parsed_doc)]
        file_type = parsed_doc.get("file_type", "")

        # -------------------------------------------------------------
        # 1. TEST CASES & RESULTS (Inspecting internal columns)
        # -------------------------------------------------------------
        all_cols = [c.lower() for c in parsed_doc.get("all_columns", [])]
        tc_schema = self.standards.get("TEST_CASES", {}).get("mandatory_columns", [])
        if all_cols and tc_schema:
            target_cols = [c.lower() for c in tc_schema]
            matched_cols = [c for c in target_cols if any(c in col for col in all_cols)]
            if len(matched_cols) >= 3:
                confidence = round(len(matched_cols) / len(target_cols), 2)
                logger.info(f"Classified '{parsed_doc.get('file_name')}' as TEST_CASES (Matched {len(matched_cols)} columns)")
                return "TEST_CASES", confidence, {
                    "matched_columns": matched_cols,
                    "total_records": parsed_doc.get("total_records", 0)
                }

        # -------------------------------------------------------------
        # 2. APPROVALS / SIGN-OFFS (Inspecting email headers or tokens)
        # -------------------------------------------------------------
        app_keywords = self.standards.get("APPROVALS", {}).get("sign_off_keywords", [
            "approved", "sign-off", "signed off", "promotion approved", 
            "production approval", "go-live approval", "accepted by", 
            "san is provided", "authorization", "change request"
        ])
        if file_type == "EMAIL" or len(headings) < 5:
            matched_tokens = [kw.lower() for kw in app_keywords if kw.lower() in full_text]
            has_sender = bool(parsed_doc.get("sender"))
            has_subject = "subject" in parsed_doc or "subject:" in full_text
            if matched_tokens or (has_sender and has_subject):
                logger.info(f"Classified '{parsed_doc.get('file_name')}' as APPROVALS")
                return "APPROVALS", 0.95, {
                    "sender": parsed_doc.get("sender", "N/A"),
                    "matched_tokens": matched_tokens
                }

        # -------------------------------------------------------------
        # 3. Dynamic Heading Evaluation for PDD, SDD, and USER_MANUAL
        # -------------------------------------------------------------
        scores = {}
        for doc_type in ["PDD", "SDD", "USER_MANUAL"]:
            schema = self.standards.get(doc_type, {})
            req_headings = [self.extractor.clean_text(h) for h in schema.get("mandatory_headings", [])]
            identifiers = [i.lower() for i in schema.get("header_identifiers", [])]

            # Match against extracted headings
            matched = [h for h in req_headings if any(h in doc_h for doc_h in headings)]

            # Check if standard heading terms appear as leading lines or prominent keywords in body
            for req_h in req_headings:
                if req_h not in matched and req_h in full_text[:4000]:
                    matched.append(req_h)

            score = len(matched) / len(req_headings) if req_headings else 0.0

            # Title block / Identifier boost
            if any(ident in full_text[:2000] for ident in identifiers):
                score += 0.35

            scores[doc_type] = (score, matched)

        best_type, (best_score, matched_sections) = max(scores.items(), key=lambda x: x[1][0])

        # A valid target document must match the minimum baseline score
        if best_score >= 0.20:
            confidence = round(min(1.0, best_score), 2)
            logger.info(f"Classified '{parsed_doc.get('file_name')}' as {best_type} (Score: {confidence}, Sections: {matched_sections[:4]})")
            return best_type, confidence, {"matched_sections": matched_sections}

        # -------------------------------------------------------------
        # 4. EXTRANEOUS (Quarantine Candidate)
        # -------------------------------------------------------------
        logger.warning(f"File '{parsed_doc.get('file_name')}' did not match any of the 5 target artifact schemas -> EXTRANEOUS")
        return "EXTRANEOUS", 0.0, {
            "reason": "Internal headings, text patterns, and tables do not match target schemas.",
            "top_headings_found": headings[:8]
        }
