"""
AI Client Module for KPMG GenAI Workbench Gateway.
Formats requests specifically for Azure APIM gateway authentication
including the mandatory 'x-kpmg-charge-code' header and strict=False JSON parsing.
"""

import os
import json
import logging
import time
import ssl
import urllib.request
import urllib.error
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("AIClient")

class AIClient:
    def __init__(self, provider: str = "azure_openai"):
        self.provider = os.getenv("AI_PROVIDER", provider).lower()
        self.api_key = os.getenv("WORKBENCH_API_KEY", "").strip()
        self.charge_code = os.getenv("KPMG_CHARGE_CODE", "00000000").strip()

        self.azure_url = os.getenv(
            "AZURE_OPENAI_API_URL",
            "https://api.workbench.kpmg/genai/azure/openai/deployments/gpt-5-1-2025-11-13-dzs-eus2/chat/completions?api-version=2024-10-21"
        )
        self.gemini_url = os.getenv(
            "GEMINI_API_URL",
            "https://api.workbench.kpmg/genai/google/gemini/v1beta/models/gemini-2.5-pro:generateContent"
        )

        self.ssl_context = ssl._create_unverified_context()
        logger.info(f"Initialized AIClient using provider: {self.provider} with charge code: {self.charge_code}")

    def generate_structured_audit(self, system_prompt: str, user_content: str, max_retries: int = 3) -> Dict[str, Any]:
        """
        Sends requests to the Workbench Gateway and parses the returned JSON with strict=False.
        """
        for attempt in range(max_retries):
            try:
                if self.provider == "azure_openai":
                    payload = {
                        "messages": [
                            {
                                "role": "system",
                                "content": f"{system_prompt}\n\nIMPORTANT: Respond ONLY with valid raw JSON without any markdown code fence."
                            },
                            {"role": "user", "content": user_content}
                        ],
                        "temperature": 0.1
                    }

                    headers = {
                        "Content-Type": "application/json",
                        "ocp-apim-subscription-key": self.api_key,
                        "Authorization": f"Bearer {self.api_key}",
                        "x-kpmg-charge-code": self.charge_code
                    }

                    req = urllib.request.Request(
                        self.azure_url,
                        data=json.dumps(payload).encode("utf-8"),
                        headers=headers,
                        method="POST"
                    )

                    with urllib.request.urlopen(req, context=self.ssl_context, timeout=120) as response:
                        res_data = json.loads(response.read().decode("utf-8"), strict=False)
                        content = res_data["choices"][0]["message"]["content"].strip()
                        if content.startswith("```json"):
                            content = content.strip("```json").strip("```").strip()
                        elif content.startswith("```"):
                            content = content.strip("```").strip()
                        # Parse with strict=False to handle control characters
                        return json.loads(content, strict=False)

                elif self.provider == "gemini":
                    payload = {
                        "contents": [{
                            "parts": [
                                {"text": f"{system_prompt}\n\nUSER INPUT:\n{user_content}\n\nRespond ONLY with valid JSON."}
                            ]
                        }],
                        "generationConfig": {"temperature": 0.1}
                    }
                    headers = {
                        "Content-Type": "application/json",
                        "ocp-apim-subscription-key": self.api_key,
                        "Authorization": f"Bearer {self.api_key}",
                        "x-kpmg-charge-code": self.charge_code
                    }

                    req = urllib.request.Request(
                        self.gemini_url,
                        data=json.dumps(payload).encode("utf-8"),
                        headers=headers,
                        method="POST"
                    )

                    with urllib.request.urlopen(req, context=self.ssl_context, timeout=120) as response:
                        res_data = json.loads(response.read().decode("utf-8"), strict=False)
                        raw_text = res_data["candidates"][0]["content"]["parts"][0]["text"].strip()
                        if raw_text.startswith("```json"):
                            raw_text = raw_text.strip("```json").strip("```").strip()
                        elif raw_text.startswith("```"):
                            raw_text = raw_text.strip("```").strip()
                        return json.loads(raw_text, strict=False)

            except urllib.error.HTTPError as http_err:
                err_body = ""
                try:
                    err_body = http_err.read().decode("utf-8")
                except Exception:
                    pass
                logger.warning(f"Workbench Gateway HTTP Error {http_err.code}: {http_err.reason}. Body: {err_body}")
                time.sleep(2 * (attempt + 1))

            except Exception as e:
                logger.warning(f"Workbench Gateway error (Attempt {attempt+1}/{max_retries}): {e}")
                time.sleep(2 * (attempt + 1))

        return {
            "document_summary": "LLM review bypassed due to gateway error.",
            "overall_quality_score": 75.0,
            "findings": []
        }
