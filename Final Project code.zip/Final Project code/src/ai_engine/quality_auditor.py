import logging
from typing import Dict, Any, List
from .client import AIClient
from .prompt_templates import QUALITY_AUDIT_SYSTEM_PROMPT, CROSS_DOC_RECONCILIATION_PROMPT

logger = logging.getLogger("QualityAuditor")

class QualityAuditor:
    def __init__(self, provider: str = "azure_openai"):
        self.client = AIClient(provider=provider)

    def review_document(self, doc_type: str, parsed_doc: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes deep cognitive quality review on a single document.
        """
        file_name = parsed_doc.get("file_name", "Unknown")
        full_text = parsed_doc.get("full_text", "")

        if not full_text or len(full_text.strip()) < 50:
            return {
                "document_summary": "Document contains insufficient text for semantic audit.",
                "overall_quality_score": 0.0,
                "findings": [{
                    "id": "GAP-EMPTY",
                    "severity": "CRITICAL",
                    "category": "Completeness",
                    "heading_section": "Document Body",
                    "issue_description": "Document has no substantive text content.",
                    "evidence_quote": "N/A",
                    "confidence": 1.0,
                    "remediation_action": "Provide a populated document."
                }]
            }

        logger.info(f"Submitting '{file_name}' ({doc_type}) to cognitive quality review...")

        # Prepare excerpt (first 10,000 characters covering Document Control, Overview, Exceptions)
        content_sample = full_text[:10000]
        user_prompt = f"DOCUMENT TYPE: {doc_type}\nFILE NAME: {file_name}\n\nCONTENT EXCERPT:\n{content_sample}"

        response = self.client.generate_structured_audit(
            system_prompt=QUALITY_AUDIT_SYSTEM_PROMPT,
            user_content=user_prompt
        )

        logger.info(f"Quality review completed for '{file_name}'. Score: {response.get('overall_quality_score', 'N/A')}")
        return response

    def reconcile_cross_documents(self, classified_docs: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Submits cross-document extracts to the LLM to verify alignment across PDD, SDD, Tests, and User Manual.
        """
        logger.info("Executing LLM Cross-Document Reconciliation...")

        pdd = classified_docs.get("PDD", {})
        sdd = classified_docs.get("SDD", {})
        test = classified_docs.get("TEST_CASES", {})
        manual = classified_docs.get("USER_MANUAL", {})

        pdd_excerpt = pdd.get("full_text", "")[:4000]
        sdd_excerpt = sdd.get("full_text", "")[:4000]
        manual_excerpt = manual.get("full_text", "")[:2000]

        # Summarize test cases
        test_summary = []
        for s_data in test.get("sheets", {}).values():
            for row in s_data.get("data", [])[:15]:
                tc_name = row.get("TC Name", "")
                tc_type = row.get("Test Scenario Type", "")
                test_summary.append(f"- {tc_name} ({tc_type})")
        test_excerpt = "\n".join(test_summary)

        combined_input = f"""
=== PDD EXCERPT ===
{pdd_excerpt}

=== SDD EXCERPT ===
{sdd_excerpt}

=== TEST CASES EXCERPT ===
{test_excerpt}

=== USER MANUAL EXCERPT ===
{manual_excerpt}
"""

        response = self.client.generate_structured_audit(
            system_prompt=CROSS_DOC_RECONCILIATION_PROMPT,
            user_content=combined_input
        )

        logger.info(f"Cross-document reconciliation finished. Aligned: {response.get('cross_document_aligned', False)}")
        return response
