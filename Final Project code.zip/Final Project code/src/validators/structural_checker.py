"""
Structural Checker Module.
Inspects extracted document structures against doc_standards.json.
Enforces:
- Heading child-content checks apply EXCLUSIVELY to PDD and SDD.
- Sections with embedded diagram images ([EMBEDDED_DIAGRAM_IMAGE]) count as valid child content.
- Unresolved placeholder tokens (TODO, TBD, [Subject], NA, ?) are flagged.
- Test Cases validate tabular execution completeness and HP/EP balance.
"""

import json
import logging
from typing import Dict, Any, List

logger = logging.getLogger("StructuralChecker")

class StructuralChecker:
    def __init__(self, standards_path: str = "config/doc_standards.json"):
        with open(standards_path, "r", encoding="utf-8") as f:
            self.standards = json.load(f)["document_types"]

    def check_document(self, doc_type: str, parsed_doc: Dict[str, Any]) -> Dict[str, Any]:
        if doc_type not in self.standards:
            return {"status": "SKIPPED", "issues": [f"No standards schema defined for {doc_type}"]}

        schema = self.standards[doc_type]
        issues = []
        findings = {}

        # -------------------------------------------------------------
        # 1. TEST CASES: Pure Tabular Inspection
        # -------------------------------------------------------------
        if doc_type == "TEST_CASES":
            sheets = parsed_doc.get("sheets", {})
            mandatory_cols = schema.get("mandatory_columns", [])
            total_records = parsed_doc.get("total_records", 0)

            findings["total_test_cases"] = total_records
            if total_records < schema.get("min_required_records", 1):
                issues.append({
                    "severity": "CRITICAL",
                    "item": "Test Case Count",
                    "message": f"Test case workbook has only {total_records} rows. Expected at least {schema.get('min_required_records', 5)}."
                })

            all_cols = [c.lower() for c in parsed_doc.get("all_columns", [])]
            missing_cols = [c for c in mandatory_cols if c.lower() not in all_cols]
            if missing_cols:
                issues.append({
                    "severity": "CRITICAL",
                    "item": "Missing Columns",
                    "message": f"Test cases sheet missing required columns: {missing_cols}"
                })

            # Check Happy Path (HP) vs Exception Path (EP) balance
            hp_count = 0
            ep_count = 0
            for s_name, s_data in sheets.items():
                for row in s_data.get("data", []):
                    tc_type = str(row.get("Test Scenario Type", "")).lower()
                    tc_name = str(row.get("TC Name", "")).lower()
                    if "happy" in tc_type or "_hp_" in tc_name:
                        hp_count += 1
                    elif "negative" in tc_type or "exception" in tc_type or "_ep_" in tc_name:
                        ep_count += 1

            findings["happy_path_count"] = hp_count
            findings["exception_path_count"] = ep_count

            if schema.get("require_both_hp_and_ep", True):
                if ep_count == 0:
                    issues.append({
                        "severity": "CRITICAL",
                        "item": "Negative Flow Coverage",
                        "message": "Zero Negative Flow / Exception Path (EP) test cases found in test workbook."
                    })
                elif hp_count == 0:
                    issues.append({
                        "severity": "CRITICAL",
                        "item": "Happy Path Coverage",
                        "message": "Zero Happy Path (HP) test cases found in test workbook."
                    })

            return {
                "doc_type": doc_type,
                "is_structurally_sound": len([i for i in issues if i["severity"] == "CRITICAL"]) == 0,
                "issues": issues,
                "findings": findings
            }

        # -------------------------------------------------------------
        # 2. APPROVALS: Bypass Heading Inspections
        # -------------------------------------------------------------
        if doc_type == "APPROVALS":
            return {
                "doc_type": doc_type,
                "is_structurally_sound": True,
                "issues": [],
                "findings": {"status": "Approvals evaluated in Stage 3"}
            }

        # -------------------------------------------------------------
        # 3. PDD & SDD: Strict Heading & Child Content Verification
        # -------------------------------------------------------------
        sections = parsed_doc.get("sections", {})
        full_text = parsed_doc.get("full_text", "")
        doc_headings = [h.lower() for h in parsed_doc.get("headings", [])]
        disallowed = schema.get("disallowed_placeholders", ["TODO", "TBD", "[Subject]"])

        # Check for Unresolved Placeholders
        for placeholder in disallowed:
            if placeholder.lower() in full_text.lower():
                issues.append({
                    "severity": "HIGH",
                    "item": "Unresolved Placeholder",
                    "message": f"Found unresolved placeholder token '{placeholder}' in document body."
                })

        # Check for Missing Mandatory Headings
        mandatory_headings = schema.get("mandatory_headings", [])
        missing_headings = []
        for req_h in mandatory_headings:
            if not any(req_h.lower() in h for h in doc_headings):
                missing_headings.append(req_h)

        if missing_headings:
            issues.append({
                "severity": "HIGH",
                "item": "Missing Mandatory Headings",
                "message": f"Document is missing standard headings: {missing_headings}"
            })

        # Check Child Content: APPLIED STRICTLY TO PDD AND SDD ONLY
        if doc_type in ["PDD", "SDD"]:
            for h_name, h_content in sections.items():
                if h_name in ["HEADER", ""]:
                    continue
                
                # Substantive content exists if:
                # 1. Text length >= 10 characters, OR
                # 2. An embedded diagram/flowchart image exists ([EMBEDDED_DIAGRAM_IMAGE]), OR
                # 3. A populated table exists ([TABLE_CONTENT)
                has_text = len(h_content.replace("[EMBEDDED_DIAGRAM_IMAGE]", "").strip()) >= 10
                has_image = "[EMBEDDED_DIAGRAM_IMAGE]" in h_content
                has_table = "[TABLE_CONTENT" in h_content

                if not (has_text or has_image or has_table):
                    issues.append({
                        "severity": "MEDIUM",
                        "item": f"Empty Section: {h_name}",
                        "message": f"Section '{h_name}' is blank (contains neither text, tables, nor an embedded diagram image)."
                    })

        # Check for Empty Tables (Tables with headers but zero data rows)
        tables = parsed_doc.get("tables", [])
        findings["total_tables"] = len(tables)
        empty_tables = [t["table_index"] for t in tables if len(t.get("rows", [])) == 0]
        if empty_tables:
            issues.append({
                "severity": "MEDIUM",
                "item": "Empty Tables",
                "message": f"Tables at index {empty_tables} contain headers but zero data rows."
            })

        return {
            "doc_type": doc_type,
            "is_structurally_sound": len([i for i in issues if i["severity"] == "CRITICAL"]) == 0,
            "issues": issues,
            "findings": findings
        }
