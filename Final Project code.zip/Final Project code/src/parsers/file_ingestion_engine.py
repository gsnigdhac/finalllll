import logging
from pathlib import Path
from typing import Dict, Any, Optional

from .docx_parser import DocxParser
from .excel_parser import ExcelParser
from .pdf_parser import PdfParser
from .email_parser import EmailParser

logger = logging.getLogger("IngestionEngine")

class FileIngestionEngine:
    def __init__(self):
        self.docx_parser = DocxParser()
        self.excel_parser = ExcelParser()
        self.pdf_parser = PdfParser()
        self.email_parser = EmailParser()

    def detect_file_type_by_bytes(self, file_path: Path) -> str:
        """Detects underlying format using file signatures (magic bytes)."""
        with open(file_path, "rb") as f:
            header = f.read(8)

        # PDF magic byte: %PDF- (0x25 0x50 0x44 0x46)
        if header.startswith(b"%PDF"):
            return "PDF"

        # OLE Compound File (legacy .doc, .xls, or Outlook .msg)
        if header.startswith(b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1"):
            # Check if it is an Outlook .msg
            return "MSG"

        # PK Zip Container (.docx, .xlsx)
        if header.startswith(b"PK\x03\x04"):
            # Inspect internal structure to differentiate docx vs xlsx
            import zipfile
            try:
                with zipfile.ZipFile(file_path, 'r') as z:
                    names = z.namelist()
                    if any("word/" in n for n in names):
                        return "DOCX"
                    elif any("xl/" in n for n in names):
                        return "XLSX"
            except Exception:
                pass

        # Fallback to suffix detection if byte inspection is inconclusive
        ext = file_path.suffix.lower()
        if ext == ".docx":
            return "DOCX"
        elif ext in [".xlsx", ".xlsm", ".csv"]:
            return "XLSX"
        elif ext == ".pdf":
            return "PDF"
        elif ext in [".msg", ".eml"]:
            return "EMAIL"

        return "UNKNOWN"

    def parse_file(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Routes file to appropriate parser and extracts normalized representation."""
        detected_type = self.detect_file_type_by_bytes(file_path)
        logger.info(f"Parsing '{file_path.name}' detected as format: {detected_type}")

        try:
            if detected_type == "DOCX":
                return self.docx_parser.parse(file_path)
            elif detected_type == "XLSX":
                return self.excel_parser.parse(file_path)
            elif detected_type == "PDF":
                return self.pdf_parser.parse(file_path)
            elif detected_type in ["MSG", "EMAIL"]:
                return self.email_parser.parse(file_path)
            else:
                logger.warning(f"Unsupported file format for {file_path.name}")
                return None
        except Exception as e:
            logger.error(f"Error parsing file {file_path.name}: {str(e)}")
            return None
