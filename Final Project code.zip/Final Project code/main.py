import os
import sys
import json
import logging
import shutil
from pathlib import Path
from datetime import datetime, timezone
from dotenv import load_dotenv

from src.parsers.content_sanitizer import ContentSanitizer
from src.parsers.file_ingestion_engine import FileIngestionEngine
from src.classifier.doc_classifier import DocumentClassifier
from src.validators.structural_checker import StructuralChecker
from src.validators.checklist_auditor import ChecklistAuditor
from src.validators.approval_validator import ApprovalValidator
from src.validators.cross_doc_reconciler import CrossDocReconciler
from src.ai_engine.quality_auditor import QualityAuditor
from src.reporting.report_builder import ReportBuilder
from src.reporting.excel_exporter import ExcelExporter

load_dotenv()

LOG_DIR = Path(os.getenv("LOG_FOLDER", "./logs"))
LOG_DIR.mkdir(parents=True, exist_ok=True)
log_file_path = LOG_DIR / "audit_processing.log"
jsonl_log_path = LOG_DIR / "audit_processing.jsonl"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[
        logging.FileHandler(log_file_path, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("Orchestrator")

def log_file_audit(file_name: str, status: str, doc_type: str = "N/A", confidence: float = 0.0, reason: str = ""):
    """Appends an entry to the JSONL log for per-file audit tracking."""
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "file_name": file_name,
        "processing_status": status,
        "classified_type": doc_type,
        "confidence": confidence,
        "details": reason
    }
    with open(jsonl_log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")

def run_pipeline():
    logger.info("=" * 70)
    logger.info("STARTING PRODUCTION CHECKLIST VALIDATOR AGENT PIPELINE")
    logger.info("=" * 70)

    input_dir = os.getenv("INPUT_FOLDER", "./input")
    quarantine_dir = os.path.join(input_dir, ".quarantine")
    output_dir = os.getenv("OUTPUT_FOLDER", "./output")
    Path(quarantine_dir).mkdir(parents=True, exist_ok=True)

    # -------------------------------------------------------------
    # STAGE 0: File Sanitization (Prune temporary Office lock files)
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 0: FILE SANITIZATION ---")
    sanitizer = ContentSanitizer(input_dir=input_dir, quarantine_dir=quarantine_dir)
    sanitization_result = sanitizer.sanitize_input_folder()
    candidate_files = sanitization_result["candidates"]

    if not candidate_files:
        logger.warning(f"No files found in '{input_dir}'. Ingestion stopped.")
        return

    # -------------------------------------------------------------
    # STAGE 1: Content Ingestion, Parsing & Classification
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 1: INGESTION & CONTENT CLASSIFICATION ---")
    ingestion_engine = FileIngestionEngine()
    classifier = DocumentClassifier()

    target_artifacts = {
        "PDD": [],
        "SDD": [],
        "TEST_CASES": [],
        "USER_MANUAL": [],
        "APPROVALS": []
    }

    for file_path in candidate_files:
        parsed_doc = ingestion_engine.parse_file(file_path)
        if not parsed_doc:
            logger.warning(f"Could not parse content from: {file_path.name}")
            dest = Path(quarantine_dir) / file_path.name
            try:
                shutil.move(str(file_path), str(dest))
            except Exception:
                pass
            log_file_audit(file_path.name, "QUARANTINED", "CORRUPT_OR_UNREADABLE", 0.0, "Parsing failed")
            continue

        doc_type, confidence, meta = classifier.classify(parsed_doc)

        # Non-target files go to .quarantine/
        if doc_type == "EXTRANEOUS":
            dest = Path(quarantine_dir) / file_path.name
            try:
                shutil.move(str(file_path), str(dest))
            except Exception:
                pass
            logger.info(f"Quarantined non-target file: {file_path.name}")
            log_file_audit(file_path.name, "QUARANTINED", "EXTRANEOUS", confidence, meta.get("reason", "Non-target content"))
            continue

        # Valid target artifact: store by category
        logger.info(f"ACCEPTED TARGET ARTIFACT: {file_path.name} -> {doc_type} (Confidence: {confidence})")
        target_artifacts[doc_type].append(parsed_doc)
        log_file_audit(file_path.name, "PROCESSED_SUCCESSFULLY", doc_type, confidence, "Matched target schema")

    logger.info("\nIngestion Summary (Accepted Target Files):")
    for k, v in target_artifacts.items():
        logger.info(f"  {k}: {len(v)} file(s)")

    # Prepare primary representations for single-file validators
    primary_artifacts = {}
    for doc_type, doc_list in target_artifacts.items():
        if doc_list:
            primary_artifacts[doc_type] = doc_list[0]

    # -------------------------------------------------------------
    # STAGE 2: Structural Verification (Heading & Table Checks)
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 2: STRUCTURAL VALIDATION ---")
    structural_checker = StructuralChecker()
    structural_results = {}

    for doc_type, doc_data in primary_artifacts.items():
        res = structural_checker.check_document(doc_type, doc_data)
        structural_results[doc_type] = res
        logger.info(f"Structural validation for {doc_type}: Sound={res.get('is_structurally_sound')}, Issues={len(res.get('issues', []))}")

    # -------------------------------------------------------------
    # STAGE 3: Promotion Checklist v1.4 Audit & Approvals
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 3: PROMOTION CHECKLIST & APPROVALS AUDIT ---")
    checklist_auditor = ChecklistAuditor()
    checklist_audit_log = checklist_auditor.audit_artifacts(primary_artifacts)

    approval_validator = ApprovalValidator()
    approval_results = approval_validator.validate_approvals(primary_artifacts)
    logger.info(f"Approvals Status: Approved={approval_results.get('all_mandatory_approvals_granted')}")

    # -------------------------------------------------------------
    # STAGE 4: Cross-Document Reconciliation
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 4: CROSS-DOCUMENT RECONCILIATION ---")
    reconciler = CrossDocReconciler()
    reconciliation_results = reconciler.reconcile_project(primary_artifacts)

    # -------------------------------------------------------------
    # STAGE 5: AI Quality Review
    # -------------------------------------------------------------
        # -------------------------------------------------------------
    # STAGE 5: AI Quality Review (All files consolidated)
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 5: AI QUALITY REVIEW ---")
    ai_auditor = QualityAuditor(provider=os.getenv("AI_PROVIDER", "azure_openai"))
    ai_quality_results = {}

    for doc_type in ["PDD", "SDD", "USER_MANUAL"]:
        if doc_type in primary_artifacts:
            ai_res = ai_auditor.review_document(doc_type, primary_artifacts[doc_type])
            ai_quality_results[doc_type] = ai_res

    # CONSOLIDATE ALL 9 TEST CASE FILES INTO ONE AUDIT FOR THE AI
    if target_artifacts["TEST_CASES"]:
        logger.info(f"Consolidating all {len(target_artifacts['TEST_CASES'])} test workbooks for AI review...")
        all_tc_lines = []
        for tc_doc in target_artifacts["TEST_CASES"]:
            file_name = tc_doc.get("file_name", "")
            all_tc_lines.append(f"\n=== WORKBOOK: {file_name} ===")
            for sheet_name, sheet_data in tc_doc.get("sheets", {}).items():
                for r in sheet_data.get("data", [])[:15]:
                    tc_name = r.get("TC Name", "Unnamed")
                    tc_type = r.get("Test Scenario Type", "")
                    actual = r.get("Actual Result", "BLANK")
                    qa_status = r.get("QA Pass/Fail", "BLANK")
                    all_tc_lines.append(f"- TC: {tc_name} | Type: {tc_type} | Actual: {actual} | Status: {qa_status}")

        consolidated_test_doc = {
            "file_name": f"Consolidated_Suite ({len(target_artifacts['TEST_CASES'])} files)",
            "full_text": "\n".join(all_tc_lines)
        }
        ai_res = ai_auditor.review_document("TEST_CASES", consolidated_test_doc)
        ai_quality_results["TEST_CASES"] = ai_res


    # -------------------------------------------------------------
    # STAGE 6: Assessment Compilation & Deliverables Generation
    # -------------------------------------------------------------
    logger.info("\n--- STAGE 6: REPORTING & DELIVERABLES GENERATION ---")
    report_builder = ReportBuilder()
    assessment_package = report_builder.compile_readiness_package(
        classified_docs=primary_artifacts,
        structural_results=structural_results,
        checklist_audit=checklist_audit_log,
        approval_results=approval_results,
        reconciliation_results=reconciliation_results,
        ai_quality_results=ai_quality_results
    )

    exporter = ExcelExporter(output_dir=output_dir)
    exporter.export_all(assessment_package)

    logger.info("=" * 70)
    logger.info("PIPELINE EXECUTION COMPLETE")
    logger.info(f"Readiness Score: {assessment_package['summary']['readiness_score']}%")
    logger.info(f"Final Decision:  {assessment_package['summary']['deployment_decision']}")
    logger.info(f"Reports saved to: {output_dir}")
    logger.info(f"Audit log saved to: {log_file_path}")
    logger.info(f"Structured JSONL log: {jsonl_log_path}")
    logger.info("=" * 70)

if __name__ == "__main__":
    run_pipeline()
