"""
Email & MSG Parser Module (Pure Python, zero compiler dependencies).
Parses both .eml and Outlook compound binary .msg files.
"""

from pathlib import Path
from typing import Dict, Any
import email
from email import policy
import re

class EmailParser:
    def parse_msg_binary(self, file_path: Path) -> str:
        """Extracts readable ASCII/Unicode text from Outlook .msg binary files."""
        try:
            with open(file_path, "rb") as f:
                content = f.read()
            # Extract printable unicode/ascii strings from OLE streams
            text_chunks = re.findall(rb"[\x20-\x7E]{4,}", content)
            decoded = [chunk.decode('ascii', errors='ignore') for chunk in text_chunks]
            # Filter out common OLE internal tokens
            clean_strings = [s for s in decoded if not s.startswith("__substg1.0_")]
            return "\n".join(clean_strings)
        except Exception:
            return ""

    def parse(self, file_path: Path) -> Dict[str, Any]:
        ext = file_path.suffix.lower()
        if ext == ".msg":
            body_text = self.parse_msg_binary(file_path)
            return {
                "file_name": file_path.name,
                "file_path": str(file_path),
                "file_type": "EMAIL",
                "sender": "Outlook Msg Record",
                "date": "",
                "subject": file_path.stem,
                "body": body_text,
                "full_text": f"Subject: {file_path.stem}\nContent:\n{body_text}"
            }
        
        # Standard .eml format
        with open(file_path, "rb") as f:
            msg = email.message_from_binary_file(f, policy=policy.default)

        sender = msg.get("From", "")
        date = msg.get("Date", "")
        subject = msg.get("Subject", "")
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body += part.get_content()
        else:
            body = msg.get_content()

        return {
            "file_name": file_path.name,
            "file_path": str(file_path),
            "file_type": "EMAIL",
            "sender": sender,
            "date": date,
            "subject": subject,
            "body": body,
            "full_text": f"Subject: {subject}\nFrom: {sender}\nDate: {date}\n\n{body}"
        }
