import os
import shutil
import logging
from pathlib import Path
from typing import List, Dict, Any

logger = logging.getLogger("Sanitizer")

class ContentSanitizer:
    def __init__(self, input_dir: str, quarantine_dir: str):
        self.input_dir = Path(input_dir)
        self.quarantine_dir = Path(quarantine_dir)
        self.quarantine_dir.mkdir(parents=True, exist_ok=True)

    def is_lock_or_temp_file(self, file_path: Path) -> bool:
        """Checks for Office lock files (~$*) or hidden OS metadata."""
        filename = file_path.name
        if filename.startswith("~$") or filename.startswith("._") or filename in [".DS_Store", "Thumbs.db", "desktop.ini"]:
            return True
        return False

    def sanitize_input_folder(self) -> Dict[str, List[Path]]:
        """
        Scans input folder, removes lock files, moves non-viable files to quarantine,
        and returns clean candidate files for processing.
        """
        candidates = []
        quarantined = []

        for item in self.input_dir.iterdir():
            if item.is_dir():
                continue

            # 1. Check lock files or temp files
            if self.is_lock_or_temp_file(item):
                logger.info(f"Removing temporary/lock file: {item.name}")
                try:
                    item.unlink()
                except Exception as e:
                    logger.warning(f"Could not delete temp file {item.name}: {e}")
                continue

            # 2. Check zero-byte or unreadable files
            if item.stat().st_size == 0:
                logger.warning(f"Quarantining 0-byte corrupt file: {item.name}")
                dest = self.quarantine_dir / item.name
                shutil.move(str(item), str(dest))
                quarantined.append(dest)
                continue

            candidates.append(item)

        logger.info(f"Sanitization complete. Valid candidates: {len(candidates)}, Quarantined: {len(quarantined)}")
        return {"candidates": candidates, "quarantined": quarantined}
