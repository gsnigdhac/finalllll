"""
DOCX Parser Module.
Extracts heading hierarchies, body text blocks, markdown tables,
and detects embedded shapes/diagrams/images as substantive child content.
"""

from pathlib import Path
from typing import Dict, Any, List
import docx

class DocxParser:
    def parse(self, file_path: Path) -> Dict[str, Any]:
        doc = docx.Document(str(file_path))
        
        full_text = []
        headings = []
        sections = {}
        current_heading = "HEADER"
        sections[current_heading] = []

        # 1. Parse Paragraphs, Headings, and Embedded Drawing/Image Elements
        for p in doc.paragraphs:
            text = p.text.strip()
            
            # Check if paragraph contains an embedded drawing, chart, shape, or picture
            has_drawing = any(
                "drawing" in child.tag.lower() or "pict" in child.tag.lower() 
                for child in p._p.iter()
            )

            # Detect Headings
            is_heading = (
                p.style.name.startswith("Heading") or 
                text.startswith("#") or
                (p.style.name.lower() in ["title", "subtitle"] and len(text.split()) < 10)
            )

            if is_heading and text:
                clean_heading = text.lstrip("#").strip()
                headings.append(clean_heading)
                current_heading = clean_heading
                if current_heading not in sections:
                    sections[current_heading] = []
            else:
                # Add text content if present
                if text:
                    full_text.append(text)
                    sections[current_heading].append(text)
                # If an image or diagram exists under this heading, record it as child content
                if has_drawing:
                    marker = "[EMBEDDED_DIAGRAM_IMAGE]"
                    sections[current_heading].append(marker)
                    full_text.append(marker)

        # 2. Parse Tables into Structured Records & Map to Current Headings
        tables_data = []
        for t_idx, table in enumerate(doc.tables):
            table_rows = []
            for row in table.rows:
                row_cells = [cell.text.strip().replace("\n", " ") for cell in row.cells]
                table_rows.append(row_cells)
            
            if table_rows:
                headers = table_rows[0]
                rows = table_rows[1:] if len(table_rows) > 1 else []
                tables_data.append({
                    "table_index": t_idx,
                    "headers": headers,
                    "rows": rows,
                    "raw_matrix": table_rows
                })
                # Add table representation to current section so it counts as substantive child content
                table_summary = " ".join([" ".join(r) for r in table_rows])
                if len(table_summary.strip()) > 5:
                    sections[current_heading].append(f"[TABLE_CONTENT: {table_summary[:200]}]")

        return {
            "file_name": file_path.name,
            "file_path": str(file_path),
            "file_type": "DOCX",
            "full_text": "\n".join(full_text),
            "headings": headings,
            "sections": {k: "\n".join(v) for k, v in sections.items()},
            "tables": tables_data
        }
