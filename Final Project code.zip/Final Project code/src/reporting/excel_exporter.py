import json
import logging
from pathlib import Path
from typing import Dict, Any
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger("ExcelExporter")

class ExcelExporter:
    def __init__(self, output_dir: str = "./output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_all(self, assessment_package: Dict[str, Any]):
        """Generates the complete set of reporting deliverables."""
        self.export_excel_report(assessment_package)
        self.export_json_log(assessment_package)
        self.export_html_dashboard(assessment_package)

    def export_json_log(self, package: Dict[str, Any]):
        """Saves machine-readable JSON gap and remediation log."""
        out_path = self.output_dir / "remediation_log.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(package, f, indent=2)
        logger.info(f"Saved JSON audit log to {out_path}")

    def export_excel_report(self, package: Dict[str, Any]):
        """Builds and styles the master Production Readiness Excel Report."""
        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # Remove default sheet

        header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
        title_font = Font(name="Segoe UI", size=14, bold=True, color="1E293B")
        bold_font = Font(name="Segoe UI", size=10, bold=True)
        regular_font = Font(name="Segoe UI", size=10)

        header_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        ready_fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
        blocked_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
        remediate_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")

        thin_border = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )

        summary_data = package["summary"]

        # -------------------------------------------------------------
        # TAB 1: EXECUTIVE SUMMARY
        # -------------------------------------------------------------
        ws_sum = wb.create_sheet(title="Executive Summary")
        ws_sum.views.sheetView[0].showGridLines = True

        ws_sum["B2"] = "AUTOMATION PRODUCTION PROMOTION READINESS REPORT"
        ws_sum["B2"].font = title_font

        ws_sum["B4"] = "Process / Shibumi ID:"
        ws_sum["C4"] = summary_data["process_id"]
        ws_sum["B5"] = "Overall Readiness Score:"
        ws_sum["C5"] = f"{summary_data['readiness_score']}%"
        ws_sum["B6"] = "Promotion Decision:"
        ws_sum["C6"] = summary_data["deployment_decision"]
        ws_sum["B7"] = "Decision Summary:"
        ws_sum["C7"] = summary_data["decision_explanation"]

        for r in range(4, 8):
            ws_sum[f"B{r}"].font = bold_font
            ws_sum[f"C{r}"].font = regular_font

        # Decision color badge
        decision = summary_data["deployment_decision"]
        if decision == "READY FOR DEPLOYMENT":
            ws_sum["C6"].fill = ready_fill
            ws_sum["C6"].font = Font(name="Segoe UI", size=11, bold=True, color="166534")
        elif decision == "BLOCKED":
            ws_sum["C6"].fill = blocked_fill
            ws_sum["C6"].font = Font(name="Segoe UI", size=11, bold=True, color="991B1B")
        else:
            ws_sum["C6"].fill = remediate_fill
            ws_sum["C6"].font = Font(name="Segoe UI", size=11, bold=True, color="92400E")

        # Metric breakdown table
        headers = ["Severity Level", "Gaps Identified", "Impact on Production"]
        metrics = [
            ("CRITICAL", summary_data["critical_gaps_count"], "Blocks Deployment. Requires immediate fix."),
            ("HIGH", summary_data["high_gaps_count"], "Significant risk. Requires remediation."),
            ("MEDIUM", summary_data["medium_gaps_count"], "Minor documentation deficiency."),
            ("LOW", summary_data["low_gaps_count"], "Best practice recommendation.")
        ]

        row_idx = 10
        for col_idx, h in enumerate(headers, start=2):
            cell = ws_sum.cell(row=row_idx, column=col_idx, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")

        for m in metrics:
            row_idx += 1
            ws_sum.cell(row=row_idx, column=2, value=m[0]).font = bold_font
            ws_sum.cell(row=row_idx, column=3, value=m[1]).font = regular_font
            ws_sum.cell(row=row_idx, column=4, value=m[2]).font = regular_font
            for c in range(2, 5):
                ws_sum.cell(row=row_idx, column=c).border = thin_border

        # -------------------------------------------------------------
        # TAB 2: PROMOTION CHECKLIST AUDIT
        # -------------------------------------------------------------
        ws_chk = wb.create_sheet(title="Promotion Checklist Audit")
        ws_chk.views.sheetView[0].showGridLines = True

        chk_headers = ["Item ID", "Section", "Checklist Requirement", "Severity", "Audit Status", "Evidence / Findings", "Confidence"]
        for col_idx, h in enumerate(chk_headers, start=1):
            cell = ws_chk.cell(row=1, column=col_idx, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")

        for r_idx, item in enumerate(package.get("checklist_audit_log", []), start=2):
            ws_chk.cell(row=r_idx, column=1, value=item.get("item_id")).font = bold_font
            ws_chk.cell(row=r_idx, column=2, value=item.get("section")).font = regular_font
            ws_chk.cell(row=r_idx, column=3, value=item.get("description")).font = regular_font
            ws_chk.cell(row=r_idx, column=4, value=item.get("severity")).font = regular_font
            
            st_cell = ws_chk.cell(row=r_idx, column=5, value=item.get("status"))
            st_cell.font = bold_font
            if item.get("status") == "SATISFIED":
                st_cell.fill = ready_fill
            elif item.get("status") == "PARTIAL":
                st_cell.fill = remediate_fill
            else:
                st_cell.fill = blocked_fill

            ws_chk.cell(row=r_idx, column=6, value=item.get("evidence")).font = regular_font
            ws_chk.cell(row=r_idx, column=7, value=f"{int(item.get('confidence', 0)*100)}%").font = regular_font

            for c in range(1, 8):
                ws_chk.cell(row=r_idx, column=c).border = thin_border

        # -------------------------------------------------------------
        # TAB 3: REMEDIATION & GAP LOG
        # -------------------------------------------------------------
        ws_gap = wb.create_sheet(title="Remediation Gap Log")
        ws_gap.views.sheetView[0].showGridLines = True

        gap_headers = ["Gap ID", "Source Artifact", "Severity", "Category", "Issue Description", "Verifiable Citation", "Actionable Remediation"]
        for col_idx, h in enumerate(gap_headers, start=1):
            cell = ws_gap.cell(row=1, column=col_idx, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")

        for r_idx, gap in enumerate(package.get("remediation_gaps", []), start=2):
            ws_gap.cell(row=r_idx, column=1, value=gap.get("gap_id")).font = bold_font
            ws_gap.cell(row=r_idx, column=2, value=gap.get("source")).font = regular_font
            
            sev_cell = ws_gap.cell(row=r_idx, column=3, value=gap.get("severity"))
            sev_cell.font = bold_font
            if gap.get("severity") == "CRITICAL":
                sev_cell.fill = blocked_fill
            elif gap.get("severity") == "HIGH":
                sev_cell.fill = remediate_fill

            ws_gap.cell(row=r_idx, column=4, value=gap.get("category")).font = regular_font
            ws_gap.cell(row=r_idx, column=5, value=gap.get("description")).font = regular_font
            ws_gap.cell(row=r_idx, column=6, value=gap.get("citation")).font = regular_font
            ws_gap.cell(row=r_idx, column=7, value=gap.get("remediation")).font = regular_font

            for c in range(1, 8):
                ws_gap.cell(row=r_idx, column=c).border = thin_border

        # Auto-adjust column widths
        for sheet in wb.worksheets:
            for col in sheet.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = get_column_letter(col[0].column)
                sheet.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 65)

        excel_path = self.output_dir / "Production_Readiness_Report.xlsx"
        wb.save(excel_path)
        logger.info(f"Saved styled Excel report to {excel_path}")

    def export_html_dashboard(self, package: Dict[str, Any]):
        """Generates an executive dashboard HTML file."""
        summary = package["summary"]
        decision = summary["deployment_decision"]
        badge_color = "#10b981" if decision == "READY FOR DEPLOYMENT" else ("#ef4444" if decision == "BLOCKED" else "#f59e0b")

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Production Readiness Dashboard - {summary['process_id']}</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 40px; }}
        .card {{ background: #1e293b; border-radius: 12px; padding: 24px; margin-bottom: 24px; border: 1px solid #334155; }}
        .badge {{ background: {badge_color}; color: #000; font-weight: bold; padding: 6px 16px; border-radius: 20px; font-size: 14px; display: inline-block; }}
        h1 {{ font-size: 24px; margin-top: 0; color: #38bdf8; }}
        .metrics {{ display: flex; gap: 20px; margin-top: 20px; }}
        .metric-box {{ background: #0f172a; padding: 16px; border-radius: 8px; flex: 1; text-align: center; border: 1px solid #334155; }}
        .metric-val {{ font-size: 28px; font-weight: bold; margin-top: 8px; color: #f8fafc; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 14px; }}
        th, td {{ padding: 10px 14px; text-align: left; border-bottom: 1px solid #334155; }}
        th {{ background: #0f172a; color: #94a3b8; }}
    </style>
</head>
<body>
    <div class="card">
        <h1>Production Promotion Readiness Assessment</h1>
        <p><strong>Process / Shibumi ID:</strong> {summary['process_id']}</p>
        <div class="badge">{decision}</div>
        <p style="margin-top: 12px; color: #cbd5e1;">{summary['decision_explanation']}</p>
        <div class="metrics">
            <div class="metric-box"><div>Readiness Score</div><div class="metric-val" style="color: #38bdf8;">{summary['readiness_score']}%</div></div>
            <div class="metric-box"><div>Critical Gaps</div><div class="metric-val" style="color: #ef4444;">{summary['critical_gaps_count']}</div></div>
            <div class="metric-box"><div>High Gaps</div><div class="metric-val" style="color: #f59e0b;">{summary['high_gaps_count']}</div></div>
            <div class="metric-box"><div>Evaluated Artifacts</div><div class="metric-val">{len(summary['artifacts_evaluated'])}</div></div>
        </div>
    </div>
    <div class="card">
        <h2>Top Remediation Gaps</h2>
        <table>
            <tr><th>Gap ID</th><th>Source</th><th>Severity</th><th>Description</th><th>Actionable Remediation</th></tr>
            {''.join(f"<tr><td>{g['gap_id']}</td><td>{g['source']}</td><td style='color: {'#ef4444' if g['severity']=='CRITICAL' else '#f59e0b'}; font-weight:bold;'>{g['severity']}</td><td>{g['description']}</td><td>{g['remediation']}</td></tr>" for g in package['remediation_gaps'][:8])}
        </table>
    </div>
</body>
</html>"""

        html_path = self.output_dir / "Executive_Summary.html"
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        logger.info(f"Saved HTML executive dashboard to {html_path}")
