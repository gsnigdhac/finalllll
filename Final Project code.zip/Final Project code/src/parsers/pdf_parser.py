from pathlib import Path
from typing import Dict, Any, List
import fitz  # PyMuPDF

class PdfParser:
    def parse(self, file_path: Path) -> Dict[str, Any]:
        doc = fitz.open(str(file_path))
        full_text = []
        headings = []
        page_texts = []

        for page_num in range(len(doc)):
            page = doc[page_num]
            text = page.get_text("text")
            page_texts.append(text)
            full_text.append(text)

            # Heuristic heading detection based on block font size
            blocks = page.get_text("blocks")
            for b in blocks:
                block_text = b[4].strip()
                lines = block_text.split("\n")
                if lines and len(lines[0]) < 80 and not lines[0].endswith("."):
                    headings.append(lines[0].strip())

        return {
            "file_name": file_path.name,
            "file_path": str(file_path),
            "file_type": "PDF",
            "page_count": len(doc),
            "full_text": "\n".join(full_text),
            "headings": list(dict.fromkeys(headings)),  # de-duplicate
            "pages": page_texts
        }
