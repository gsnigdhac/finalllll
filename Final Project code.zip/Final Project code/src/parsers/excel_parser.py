"""
Excel Parser Module (Pure Python, zero pandas dependency).
Parses Test Cases sheets (16 standard columns) and generates full_text for LLM.
"""

from pathlib import Path
from typing import Dict, Any, List
import openpyxl

class ExcelParser:
    def parse(self, file_path: Path) -> Dict[str, Any]:
        wb = openpyxl.load_workbook(str(file_path), data_only=True)
        sheets_data = {}
        all_columns = []
        total_rows = 0
        text_lines = [f"Workbook: {file_path.name}"]

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = list(ws.iter_rows(values_only=True))
            if not rows:
                continue

            # First non-empty row as header
            header_row = [str(cell).strip() if cell is not None else "" for cell in rows[0]]
            columns = [c for c in header_row if c]
            all_columns.extend(columns)

            records = []
            text_lines.append(f"\n--- Sheet: {sheet_name} ---")
            for row in rows[1:]:
                if not any(row):
                    continue
                record = {}
                row_str_items = []
                for idx, col_name in enumerate(columns):
                    val = row[idx] if idx < len(row) else ""
                    val_str = str(val).strip() if val is not None else ""
                    record[col_name] = val_str
                    if col_name in ["TC Name", "Test Scenario Type", "Steps", "Expected Result", "Actual Result", "QA Pass/Fail"]:
                        row_str_items.append(f"{col_name}: {val_str}")
                
                records.append(record)
                if row_str_items:
                    text_lines.append(" | ".join(row_str_items))

            total_rows += len(records)
            sheets_data[sheet_name] = {
                "columns": columns,
                "row_count": len(records),
                "data": records
            }

        return {
            "file_name": file_path.name,
            "file_path": str(file_path),
            "file_type": "XLSX",
            "sheet_names": wb.sheetnames,
            "sheets": sheets_data,
            "all_columns": list(set(all_columns)),
            "total_records": total_rows,
            "full_text": "\n".join(text_lines)  # Enables AI to read test case content
        }
