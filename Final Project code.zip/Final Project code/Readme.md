production-checklist-validator/
│
├── config/
│   ├── promotion_checklist_master.json   # Master Promotion Checklist v1.4 rules & criteria
│   ├── doc_standards.json                # Standard static headings & schemas for the 5 target artifacts
│   └── settings.yaml                     # Model selection (Azure OpenAI/Gemini), API keys, thresholds
│
├── input/                                # Local drop folder populated by SharePoint download robot
│   └── .quarantine/                      # Auto-isolated non-target / extraneous / junk files
│
├── output/                               # Final generated release governance deliverables
│   ├── Production_Readiness_Report.xlsx  # Master readiness workbook (Summary, Checklist, Gap Log)
│   ├── Executive_Summary.html            # Leadership sign-off dashboard with Go/No-Go badge
│   └── remediation_log.json              # Traceable JSON gap log with citations & confidence scores
│
├── src/
│   ├── __init__.py
│   │
│   ├── parsers/                          # Content-first ingestion & deep structural parsing
│   │   ├── __init__.py
│   │   ├── content_sanitizer.py          # Prunes temp locks, non-project files; quarantines non-targets
│   │   ├── file_ingestion_engine.py      # Magic-byte inspector & multi-format router (ignores file ext)
│   │   ├── docx_parser.py                # Extracts standard heading hierarchies, paragraphs & tables
│   │   ├── pdf_parser.py                 # PyMuPDF text & structural layout extractor
│   │   ├── excel_parser.py               # Reads 16-column Test Cases sheets & results matrices
│   │   └── email_parser.py               # Parses standalone approval emails (.msg/.eml) for sign-off text
│   │
│   ├── classifier/                       # Content-based document categorization
│   │   ├── __init__.py
│   │   ├── heading_extractor.py          # Normalizes Table of Contents & internal section headers
│   │   └── doc_classifier.py             # Classifies content strictly into: PDD, SDD, Test Suite, Manual, Approval
│   │
│   ├── validators/                       # Core governance & audit engines
│   │   ├── __init__.py
│   │   ├── checklist_auditor.py          # Audits documents against master checklist rules from config/
│   │   ├── structural_checker.py         # Detects missing sections, empty tables & placeholder tokens
│   │   ├── approval_validator.py         # Validates sign-offs across embedded tables & standalone files
│   │   └── cross_doc_reconciler.py       # Cross-reconciles PDD rules ↔ SDD architecture ↔ QA Test Cases
│   │
│   ├── ai_engine/                        # Generative AI cognitive review orchestration
│   │   ├── __init__.py
│   │   ├── client.py                     # API client wrapper for Azure OpenAI / Google Gemini
│   │   ├── prompt_templates.py           # Structured prompts & JSON schemas for audits and citations
│   │   └── quality_auditor.py            # Evaluates architectural depth, exception matrices & security
│   │
│   └── reporting/                        # Consolidation & deliverable generation
│       ├── __init__.py
│       ├── report_builder.py             # Computes readiness scores and Go / Remediation / Blocked status
│       └── excel_exporter.py             # Formats and writes the audit-ready Excel and HTML reports
│
├── requirements.txt                      # python-docx, PyMuPDF, openpyxl, pandas, extract-msg, jinja2, pydantic
└── main.py                               # Pipeline CLI orchestrator and entry point

Packages to be installed 


pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org python-docx PyMuPDF openpyxl openai python-dotenv pydantic pyyaml jinja2                    


Run
python main.py


