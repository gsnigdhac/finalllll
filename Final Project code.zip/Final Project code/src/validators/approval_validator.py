import logging
from typing import Dict, Any, List

logger = logging.getLogger("ApprovalValidator")

class ApprovalValidator:
    def validate_approvals(self, classified_docs: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Cross-validates approval status across standalone emails and embedded PDD/SDD tables.
        """
        pdd = classified_docs.get("PDD", {})
        sdd = classified_docs.get("SDD", {})
        approval_file = classified_docs.get("APPROVALS", {})

        business_owner_approved = False
        process_owner_approved = False
        sign_off_sources = []
        approver_emails = []

        # 1. Inspect Standalone Approval Artifact (e.g., .msg file)
        if approval_file:
            text = approval_file.get("full_text", "").lower()
            sender = approval_file.get("sender", "")
            if sender:
                approver_emails.append(sender)

            sign_off_keywords = ["approved", "sign-off granted", "promotion approved", "accepted"]
            if any(kw in text for kw in sign_off_keywords):
                sign_off_sources.append(f"Standalone Artifact: {approval_file.get('file_name')}")
                business_owner_approved = True
                process_owner_approved = True

        # 2. Inspect Embedded PDD Approvals Table
        pdd_tables = pdd.get("tables", [])
        for t in pdd_tables:
            headers = [str(h).lower() for h in t.get("headers", [])]
            if any("approval" in h for h in headers) or any("role" in h for h in headers):
                for row in t.get("rows", []):
                    row_str = " ".join([str(c) for c in row]).lower()
                    if "business owner" in row_str and len(row) >= 3 and len(str(row[-1]).strip()) > 1:
                        business_owner_approved = True
                        sign_off_sources.append("PDD Approvals Table (Business Owner)")
                    if "process owner" in row_str and len(row) >= 3 and len(str(row[-1]).strip()) > 1:
                        process_owner_approved = True
                        sign_off_sources.append("PDD Approvals Table (Process Owner)")

        # 3. Inspect SDD Version History / Document Control
        sdd_tables = sdd.get("tables", [])
        for t in sdd_tables:
            headers = [str(h).lower() for h in t.get("headers", [])]
            if any("approved by" in h for h in headers):
                for row in t.get("rows", []):
                    if len(row) >= 4 and len(str(row[-1]).strip()) > 2:
                        sign_off_sources.append("SDD Document Control Approver")

        all_approved = business_owner_approved and process_owner_approved

        return {
            "all_mandatory_approvals_granted": all_approved,
            "business_owner_approved": business_owner_approved,
            "process_owner_approved": process_owner_approved,
            "sign_off_sources": list(set(sign_off_sources)),
            "approver_emails": approver_emails,
            "is_release_blocked": not all_approved
        }
