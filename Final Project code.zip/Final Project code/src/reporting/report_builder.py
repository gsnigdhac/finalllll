
import logging
from typing import Dict, Any, List

logger = logging.getLogger("ReportBuilder")

class ReportBuilder:
    def __init__(self, thresholds: Dict[str, Any] = None):
        self.thresholds = thresholds or {
            "min_acceptable_readiness_score": 85.0,
            "max_allowed_critical_gaps": 0,
            "max_allowed_high_gaps": 2
        }

    def compile_readiness_package(
        self,
        classified_docs: Dict[str, Dict[str, Any]],
        structural_results: Dict[str, Dict[str, Any]],
        checklist_audit: List[Dict[str, Any]],
        approval_results: Dict[str, Any],
        reconciliation_results: Dict[str, Any],
        ai_quality_results: Dict[str, Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Synthesizes all pipeline outputs into a comprehensive governance evaluation.
        """
        logger.info("Compiling final Production Readiness Assessment Package...")

        # 1. Compile All Discovered Gaps & Findings
        consolidated_gaps = []
        gap_counter = 1

        # Add Structural Issues
        for doc_type, res in structural_results.items():
            for issue in res.get("issues", []):
                consolidated_gaps.append({
                    "gap_id": f"STRUC-{gap_counter:03d}",
                    "source": doc_type,
                    "severity": issue.get("severity", "MEDIUM"),
                    "category": "Structural Integrity",
                    "description": f"[{issue.get('item')}] {issue.get('message')}",
                    "citation": "Document Standard Heading / Template Structure",
                    "confidence": 1.0,
                    "remediation": "Update document to include mandatory headings, eliminate placeholders, or balance test cases."
                })
                gap_counter += 1

        # Add Checklist Audit Deficiencies (Items not marked SATISFIED)
        for item in checklist_audit:
            if item.get("status") in ["NOT_FOUND", "PARTIAL"]:
                consolidated_gaps.append({
                    "gap_id": f"CHK-{gap_counter:03d}",
                    "source": item.get("section", "Promotion Checklist"),
                    "severity": item.get("severity", "HIGH"),
                    "category": "Promotion Governance",
                    "description": f"[{item.get('item_id')}] {item.get('description')}: {item.get('evidence')}",
                    "citation": f"Checklist Item {item.get('item_id')}",
                    "confidence": item.get("confidence", 0.9),
                    "remediation": f"Provide required evidence for {item.get('item_id')} to satisfy Promotion Checklist v1.4."
                })
                gap_counter += 1

        # Add Approval Gaps
        if approval_results.get("is_release_blocked", False):
            consolidated_gaps.append({
                "gap_id": f"APP-{gap_counter:03d}",
                "source": "Approvals",
                "severity": "CRITICAL",
                "category": "Sign-Off Governance",
                "description": "Mandatory Business Owner or Process Owner sign-off is missing.",
                "citation": "PDD Approvals Table / Standalone Approval Email",
                "confidence": 1.0,
                "remediation": "Obtain written sign-off from both Business Owner and Process Owner before deployment."
            })
            gap_counter += 1

        # Add Cross-Document Discrepancies
        for issue in reconciliation_results.get("issues", []):
            consolidated_gaps.append({
                "gap_id": f"RECON-{gap_counter:03d}",
                "source": "Multi-Document Reconciliation",
                "severity": issue.get("severity", "HIGH"),
                "category": "Cross-Document Traceability",
                "description": f"[{issue.get('area')}] {issue.get('message')}",
                "citation": "PDD <-> SDD <-> Test Cases Matrix",
                "confidence": 0.95,
                "remediation": "Align Shibumi IDs, ensure all PDD business exceptions have SDD technical handling and QA test cases."
            })
            gap_counter += 1

        # Add AI Semantic Quality Findings
        for doc_type, ai_res in ai_quality_results.items():
            for finding in ai_res.get("findings", []):
                consolidated_gaps.append({
                    "gap_id": f"AI-{gap_counter:03d}",
                    "source": doc_type,
                    "severity": finding.get("severity", "MEDIUM"),
                    "category": finding.get("category", "Semantic Quality"),
                    "description": finding.get("issue_description", ""),
                    "citation": f"Section: {finding.get('heading_section')} | Quote: \"{finding.get('evidence_quote')}\"",
                    "confidence": finding.get("confidence", 0.9),
                    "remediation": finding.get("remediation_action", "")
                })
                gap_counter += 1

        # 2. Score Calculation
        critical_gaps = len([g for g in consolidated_gaps if g["severity"] == "CRITICAL"])
        high_gaps = len([g for g in consolidated_gaps if g["severity"] == "HIGH"])
        medium_gaps = len([g for g in consolidated_gaps if g["severity"] == "MEDIUM"])
        low_gaps = len([g for g in consolidated_gaps if g["severity"] == "LOW"])

        # Base score 100, deductions per severity level
        deductions = (critical_gaps * 25.0) + (high_gaps * 10.0) + (medium_gaps * 4.0) + (low_gaps * 1.0)
        final_score = max(0.0, round(100.0 - deductions, 1))

        # 3. Decision Logic
        if critical_gaps > self.thresholds["max_allowed_critical_gaps"]:
            decision = "BLOCKED"
            decision_summary = f"Release is BLOCKED. Found {critical_gaps} Critical blocking gaps (e.g. missing approvals or core architectural voids)."
        elif final_score < self.thresholds["min_acceptable_readiness_score"] or high_gaps > self.thresholds["max_allowed_high_gaps"]:
            decision = "REQUIRES REMEDIATION"
            decision_summary = f"Release REQUIRES REMEDIATION. Overall score ({final_score}%) is below {self.thresholds['min_acceptable_readiness_score']}% or exceeds High risk threshold ({high_gaps} High gaps)."
        else:
            decision = "READY FOR DEPLOYMENT"
            decision_summary = "All artifacts meet Promotion Checklist v1.4 and Nexus Automation quality standards."

        package = {
            "summary": {
                "process_id": reconciliation_results.get("alignment_summary", {}).get("unified_process_id", "UNKNOWN"),
                "readiness_score": final_score,
                "deployment_decision": decision,
                "decision_explanation": decision_summary,
                "critical_gaps_count": critical_gaps,
                "high_gaps_count": high_gaps,
                "medium_gaps_count": medium_gaps,
                "low_gaps_count": low_gaps,
                "total_gaps_identified": len(consolidated_gaps),
                "artifacts_evaluated": list(classified_docs.keys())
            },
            "checklist_audit_log": checklist_audit,
            "remediation_gaps": consolidated_gaps,
            "approvals_summary": approval_results,
            "reconciliation_summary": reconciliation_results
        }

        logger.info(f"Assessment complete. Decision: {decision} (Score: {final_score}%)")
        return package
