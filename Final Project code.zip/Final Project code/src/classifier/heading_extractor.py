import re
from typing import List, Dict, Any

class HeadingExtractor:
    @staticmethod
    def clean_text(text: str) -> str:
        """Lowercases, removes punctuation, numbers, and extra whitespace."""
        if not text:
            return ""
        # Remove markdown symbols, numbered prefixes like '1.', '1.1', etc.
        text = re.sub(r"^[0-9]+(\.[0-9]+)*\s*", "", text.strip())
        text = re.sub(r"[^\w\s]", " ", text)
        return " ".join(text.lower().split())

    def extract_normalized_headings(self, parsed_doc: Dict[str, Any]) -> List[str]:
        """
        Extracts all heading strings and table names, cleaning them
        for deterministic or fuzzy template comparison.
        """
        raw_headings = parsed_doc.get("headings", [])
        normalized = []
        for h in raw_headings:
            cleaned = self.clean_text(h)
            if cleaned and cleaned not in normalized:
                normalized.append(cleaned)
        
        # If no explicit headings exist (e.g. raw text), extract leading lines
        if not normalized and "full_text" in parsed_doc:
            lines = parsed_doc["full_text"].split("\n")[:50]
            for line in lines:
                cleaned = self.clean_text(line)
                if len(cleaned.split()) <= 8 and cleaned:
                    normalized.append(cleaned)

        return normalized
